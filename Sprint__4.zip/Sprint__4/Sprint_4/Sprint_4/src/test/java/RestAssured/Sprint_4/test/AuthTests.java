
package RestAssured.Sprint_4.test;

import RestAssured.Sprint_4.base.BaseTest_Extent;
import RestAssured.Sprint_4.utils.JsonReader;
import RestAssured.Sprint_4.services.AuthService;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

import java.util.Map;

public class AuthTests extends BaseTest_Extent {

    public AuthService authService = new AuthService();
    public static Map<String, Object> jsonData = JsonReader.readJson();
    private ExtentTest test;

    @Test(priority = 1, description = "Verify a valid auth code can be obtained")
    public void testGetAuthCode() {
        test = extent.createTest("Get Auth Code Test");
        
        test.log(Status.INFO, "Fetching username and password from JSON data.");
        String userName = (String) jsonData.get("username");
        String passWord = (String) jsonData.get("password");
        
        String requestBody = "username=" + userName + "&" + "password=" + passWord;
        test.log(Status.INFO, "Request Body: " + requestBody);

        Response response = authService.getAuthCode(requestBody);
        
        test.log(Status.INFO, "API call to get auth code completed.");
        test.log(Status.INFO, "Response Status Code: " + response.getStatusCode());
        test.log(Status.INFO, "Response Body: " + response.getBody().asString());

        try {
            response.then()
                .statusCode(200)
                .body("", not(empty()))
                .body("auth_code", notNullValue());
            test.log(Status.PASS, "Successfully verified status code, body, and auth_code field.");
        } catch (AssertionError e) {
            test.log(Status.FAIL, "Auth code assertions failed!");
            test.log(Status.FAIL, e);
            Assert.fail(e.getMessage());
        }
        
        String authCode = response.then().extract().path("auth_code");
        test.log(Status.INFO, "Extracted auth_code: " + authCode);
        
        JsonReader.updateJsonData("auth_code", authCode);
        test.log(Status.INFO, "Updated local JSON file with the new auth_code.");
    }
    
    @Test(priority = 2, description = "Verify an access token can be obtained with a valid auth code")
    public void testGetAccessToken() {
        test = extent.createTest("Get Access Token Test");
        
        test.log(Status.INFO, "Fetching auth_code from JSON data.");
        String authCode = (String) jsonData.get("auth_code");
        
        String requestBody = "auth_code=" + authCode;
        test.log(Status.INFO, "Request Body: " + requestBody);
        
        Response response = authService.getAccessToken(requestBody);
        
        test.log(Status.INFO, "API call to get access token completed.");
        test.log(Status.INFO, "Response Status Code: " + response.getStatusCode());
        test.log(Status.INFO, "Response Body: " + response.getBody().asString());
        
        try {
            response.then()
                .statusCode(200)
                .body("", not(empty()))
                .body("access_token", notNullValue());
            test.log(Status.PASS, "Successfully verified status code, body, and access_token field.");
        } catch (AssertionError e) {
            test.log(Status.FAIL, "Access token assertions failed!");
            test.log(Status.FAIL, e);
            Assert.fail(e.getMessage());
        }
        
        String accessToken = response.then().extract().path("access_token");
        test.log(Status.INFO, "Extracted access_token: " + accessToken);
        
        JsonReader.updateJsonData("access_token", accessToken);
        test.log(Status.INFO, "Updated local JSON file with the new access_token.");
    }
}

