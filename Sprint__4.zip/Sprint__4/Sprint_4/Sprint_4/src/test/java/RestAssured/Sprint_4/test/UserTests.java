 package RestAssured.Sprint_4.test;

import RestAssured.Sprint_4.base.BaseTest_Extent;
import RestAssured.Sprint_4.services.UserService;
import RestAssured.Sprint_4.utils.JsonReader;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import io.restassured.response.Response;
import org.testng.Assert; // Use TestNG's Assert
import org.testng.annotations.Test;
import static org.hamcrest.Matchers.*;

import java.util.Map;


public class UserTests extends BaseTest_Extent {

    private final UserService userService = new UserService();
    private ExtentTest test;
    public static int statuscode;
    public static String requestMethod;
    public static Map<String, Object> jsonData = JsonReader.readJson();
    
    // Test data from JSON
    String userId = (String) jsonData.get("userId");
    String emailId = (String) jsonData.get("emailId");
    String aadhaarNumber = (String) jsonData.get("aadhaarNumber");
    String firstName = (String) jsonData.get("firstName");
    String lastName = (String) jsonData.get("lastName");
    String phoneNumber = (String) jsonData.get("phoneNumber");
    String gender = (String) jsonData.get("gender");

    @Test(priority = 3, description = "Verify a new user can be added successfully")
    public void testAddUser() {
        test = extent.createTest("Add New User Test");
        
        test.log(Status.INFO, "Creating request body for a new user.");
        String requestBody = "userId=" + userId + "&"
                + "emailId=" + emailId + "&"
                + "aadhaarNumber=" + aadhaarNumber + "&"
                + "firstName=" + firstName + "&"
                + "lastName=" + lastName + "&"
                + "phoneNumber=" + phoneNumber + "&"
                + "gender=" + gender;
        test.log(Status.INFO, "Request Body: " + requestBody);
        

        Response response = userService.addUser(requestBody);
        
        test.log(Status.INFO, "POST request sent to add a new user.");
        test.log(Status.INFO, "Response Status Code: " + response.getStatusCode());
        test.log(Status.INFO, "Response Body: " + response.getBody().asString());

        try {
            response.then().statusCode(200)
                           .body("", not(empty()))
                           .body("find { it.userId == " + userId + " }", notNullValue());
            test.log(Status.PASS, "User added successfully and response assertions passed.");
        } catch (AssertionError e) {
            test.log(Status.FAIL, "Failed to add a new user or assertions failed.");
            test.log(Status.FAIL, e);
            Assert.fail(e.getMessage());
        }
    }

    @Test(priority = 4, description = "Verify all users can be retrieved")
    public void testViewUserList() {
        test = extent.createTest("View All Users List Test");

        Response response = userService.viewUserList();
        
        test.log(Status.INFO, "GET request sent to view all users.");
        test.log(Status.INFO, "Response Status Code: " + response.getStatusCode());
        test.log(Status.INFO, "Response Body: " + response.getBody().asString());
        
        try {
            response.then().statusCode(200)
                    .body("", not(empty()))
                    .body("size()", greaterThan(0));
            test.log(Status.PASS, "Successfully retrieved a non-empty list of all users.");
        } catch (AssertionError e) {
            test.log(Status.FAIL, "Failed to retrieve the user list or assertions failed.");
            test.log(Status.FAIL, e);
            Assert.fail(e.getMessage());
        }
    }   
    
    @Test(priority = 5, description = "Verify a specific user can be retrieved by ID")
    public void testViewUserById() {
        test = extent.createTest("View User by ID Test");
        
        test.log(Status.INFO, "Sending GET request to view user with ID: " + userId);
        Response response = userService.viewUserById(userId);
        
        test.log(Status.INFO, "Response Status Code: " + response.getStatusCode());
        test.log(Status.INFO, "Response Body: " + response.getBody().asString());

        try {
            Assert.assertEquals(response.getStatusCode(), 200);
            response.then().body("userId", equalTo(Integer.parseInt(userId)));
            response.then().body("firstName", equalTo(firstName));
            test.log(Status.PASS, "Successfully retrieved user by ID and verified response data.");
        } catch (AssertionError e) {
            test.log(Status.FAIL, "Failed to retrieve user by ID or data did not match.");
            test.log(Status.FAIL, e);
            Assert.fail(e.getMessage());
        }
    }

    @Test(priority = 6, description = "Verify users can be viewed by gender")
    public void testViewUserByGender() {
        test = extent.createTest("View Users by Gender Test");
        
        String Gender = "Male"; 
        test.log(Status.INFO, "Sending GET request to view users with gender: " + Gender);

        Response response = userService.viewUserByGender(Gender);
        
        test.log(Status.INFO, "Response Status Code: " + response.getStatusCode());
        test.log(Status.INFO, "Response Body: " + response.getBody().asString());
        
        try {
            response.then()
                .statusCode(200)
                .body("", not(empty()))
                .body("every { it.gender == 'Male' }", is(true));
            test.log(Status.PASS, "Successfully retrieved a list of users, all with gender 'Male'.");
        } catch (AssertionError e) {
            test.log(Status.FAIL, "Failed to filter users by gender or assertions failed.");
            test.log(Status.FAIL, e);
            Assert.fail(e.getMessage());
        }
    }

    @Test(priority = 7, description = "Verify a user's phone number can be updated")
    public void testUpdateUserNumber() {      
        test = extent.createTest("Update User's Phone Number Test");
        
        String UserId = "10001";               
        String phoneNumber = "1234567890";
        test.log(Status.INFO, "Updating phone number for User ID " + UserId + " to " + phoneNumber);
    

        Response response = userService.updateUserNumber(UserId, phoneNumber);
        
        test.log(Status.INFO, "PUT request sent to update the user's phone number.");
        test.log(Status.INFO, "Response Status Code: " + response.getStatusCode());
        
        try {
            Assert.assertEquals(response.getStatusCode(), 200);
            test.log(Status.PASS, "Phone number update request succeeded with status code 200.");
        } catch (AssertionError e) {
            test.log(Status.FAIL, "Phone number update request failed.");
            test.log(Status.FAIL, e);
            Assert.fail(e.getMessage());
        }
        
        test.log(Status.INFO, "Verifying the update by retrieving the user again.");
        Response viewResponse = userService.viewUserById(UserId);
        try {
            viewResponse.then().body("phoneNumber", equalTo(phoneNumber));
            test.log(Status.PASS, "Successfully verified the updated phone number.");
        } catch (AssertionError e) {
            test.log(Status.FAIL, "Verification of updated phone number failed.");
            test.log(Status.FAIL, e);
            Assert.fail(e.getMessage());
        }
    }

    @Test(priority = 8, description = "Verify a user can be deleted by ID")
    public void testDeleteUserById() {
        test = extent.createTest("Delete User by ID Test");
        
        String UserId = "10002"; 
        test.log(Status.INFO, "Sending DELETE request for user with ID: " + UserId);
        Response response = userService.deleteUserById(UserId);
        
        test.log(Status.INFO, "Response Status Code: " + response.getStatusCode());

        try {
            response.then().statusCode(200);
            response.then().body("find { it.userId == " + UserId + " }", nullValue());
            test.log(Status.PASS, "Successfully deleted user with ID " + UserId + ".");
        } catch (AssertionError e) {
            test.log(Status.FAIL, "User deletion failed or assertion on response body failed.");
            test.log(Status.FAIL, e);
            Assert.fail(e.getMessage());
        }
    }
}
