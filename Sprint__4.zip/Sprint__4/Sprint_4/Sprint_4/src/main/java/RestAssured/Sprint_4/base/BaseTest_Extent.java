

package RestAssured.Sprint_4.base;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import java.io.File;

/**
 * Base class for all test classes to handle the Extent Report setup and teardown.
 */
public class BaseTest_Extent {

    protected static ExtentReports extent;

    @BeforeSuite
    public void setUp() {
        String reportPath = "target/extent-reports/ExtentReport.html";
        File reportDir = new File("target/extent-reports");
        if (!reportDir.exists()) {
            reportDir.mkdirs();
        }

        ExtentSparkReporter sparkReporter = new ExtentSparkReporter(reportPath);
        
        extent = new ExtentReports();
        extent.attachReporter(sparkReporter);

        sparkReporter.config().setDocumentTitle("Extent Report");
        sparkReporter.config().setReportName("API Test Execution Results");
    }

    @AfterSuite
    public void tearDown() {
        extent.flush();
    }
}

