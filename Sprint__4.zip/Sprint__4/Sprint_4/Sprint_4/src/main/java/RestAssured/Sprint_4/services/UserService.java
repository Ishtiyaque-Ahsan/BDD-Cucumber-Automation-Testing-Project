package RestAssured.Sprint_4.services;

import RestAssured.Sprint_4.base.BaseTest_Extent;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class UserService extends BaseTest_Extent {
	public static RequestSpecification httpRequest;
    public static Response response;
    
    
    String HOTEL_API_BASE_URI = "https://webapps.tekstac.com/HotelAPI";
    public Response addUser(String requestBody) {
     
        RestAssured.baseURI = "https://webapps.tekstac.com/HotelAPI/UserService/addUser";
        httpRequest = RestAssured.given()
                .header("accept", "application/json")
                .header("Content-Type", "application/x-www-form-urlencoded");
        
    	        
        response = httpRequest
                .body(requestBody)
                .post();
        return response;

    }

    public Response viewUserList() {
    	RestAssured.baseURI = "https://webapps.tekstac.com/HotelAPI/UserService/viewUserList";
        httpRequest = RestAssured.given()
                .header("accept", "application/json");
        response = httpRequest.get();
        return response;
    }

    public Response viewUserById(String userId) {
    	RestAssured.baseURI = "https://webapps.tekstac.com/HotelAPI/UserService/viewUserById/10001";
        httpRequest = RestAssured.given()
                .header("accept", "application/json");
        response = httpRequest.get();
        return response;
    }

   
    public Response viewUserByGender(String gender) {
    	RestAssured.baseURI = "https://webapps.tekstac.com/HotelAPI/UserService/viewUserByGender/Male";
        httpRequest = RestAssured.given()
                .header("accept", "application/json");
        response = httpRequest.get();
        return response;
    }

    public Response updateUserNumber(String userId, String phoneNumber) {
        
        
        RestAssured.baseURI = "https://webapps.tekstac.com/HotelAPI/UserService/updateUserNumber";
        httpRequest = RestAssured.given()
                .header("Accept", "application/json")
                .header("Content-Type", "application/x-www-form-urlencoded");
   	      
        response = httpRequest
                .queryParam("cinemaHallId", userId)
                .queryParam("ticketPrice", phoneNumber)
                .put();
        return response;
    }

    
    public Response deleteUserById(String userId) {
    	
    	RestAssured.baseURI = "https://webapps.tekstac.com/HotelAPI/UserService/deleteUserById/10002";
        httpRequest = RestAssured.given()
                .header("Accept", "application/json");
        
        response = httpRequest               
                .delete();
        return response;
    }
}
