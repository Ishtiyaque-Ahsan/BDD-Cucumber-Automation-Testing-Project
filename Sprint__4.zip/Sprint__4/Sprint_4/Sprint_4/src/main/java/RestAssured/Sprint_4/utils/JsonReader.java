package RestAssured.Sprint_4.utils;

import org.json.JSONObject;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Collections;


public class JsonReader {

 private static final String filePath = "src/main/java/data.json";

 
 public static Map<String, Object> readJson() {
     Map<String, Object> jsonMap = new HashMap<>();

     try {
         String content = new String(Files.readAllBytes(Paths.get(filePath)));
         JSONObject jsonObject = new JSONObject(content);
         
         for (String key : jsonObject.keySet()) {
             Object value = jsonObject.get(key);
             jsonMap.put(key, value);
         }
     } catch (IOException e) {
         System.err.println("Error reading file: " + e.getMessage());
         e.printStackTrace();
     } catch (org.json.JSONException e) {
         System.err.println("Error parsing JSON: " + e.getMessage());
         e.printStackTrace();
     }

     return jsonMap;
 }
 
 
 public static void updateJsonData(String key, Object value) {
     try {
         Map<String, Object> jsonMap = readJson();
         
         jsonMap.put(key, value);
         
         JSONObject jsonObject = new JSONObject(jsonMap);
         Files.write(Paths.get(filePath), Collections.singletonList(jsonObject.toString(4)));
         
         System.out.println("Updated key '" + key + "' with value '" + value + "'. Data written to file.");
         
     } catch (IOException e) {
         System.err.println("Error writing to file: " + e.getMessage());
         e.printStackTrace();
     } catch (org.json.JSONException e) {
         System.err.println("Error parsing JSON: " + e.getMessage());
         e.printStackTrace();
     }
 }
 
 
}
