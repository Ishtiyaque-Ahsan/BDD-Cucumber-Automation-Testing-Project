package RestAssured.Sprint_4.services;

import RestAssured.Sprint_4.base.BaseTest_Extent;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class AuthService extends BaseTest_Extent {

    
    public static RequestSpecification httpRequest;
    public static Response response;
  
    public Response getAuthCode(String requestBody) {
        
        RestAssured.baseURI = "https://webapps.tekstac.com/OAuthRestApi/webapi/auth/login";
        httpRequest = RestAssured.given()
                .header("accept", "application/json")
                .header("Content-Type", "application/x-www-form-urlencoded");
        
    	        
        response = httpRequest
                .body(requestBody)
                .post();
        return response;

    }
public Response getAccessToken(String requestBody) {
        
        RestAssured.baseURI = "https://webapps.tekstac.com/OAuthRestApi/webapi/auth/token";
        httpRequest = RestAssured.given()
                .header("accept", "application/json")
                .header("Content-Type", "application/x-www-form-urlencoded");
        
    	        
        response = httpRequest
                .body(requestBody)
                .post();
        return response;

    }

 
}
